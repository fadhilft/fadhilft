import React from 'react';
import { Code, Palette, Layers, Coffee, MapPin } from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    { number: '3+', label: 'Years Experience' },
    { number: '50+', label: 'Projects Completed' },
    { number: '15+', label: 'Happy Clients' },
    { number: '100%', label: 'Satisfaction Rate' },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-800 mb-6">
            About Me
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            I'm a passionate developer from Thrissur, Kerala, who loves creating exceptional digital experiences
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Code className="w-6 h-6 text-teal-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">Full-Stack Development</h3>
                  <p className="text-slate-600">
                    I build complete web applications from frontend to backend, ensuring seamless user experiences and robust functionality.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Palette className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">Web Design</h3>
                  <p className="text-slate-600">
                    Creating visually stunning and user-friendly designs that not only look great but also provide intuitive user experiences.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Layers className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">UI Development</h3>
                  <p className="text-slate-600">
                    Transforming designs into pixel-perfect, responsive interfaces using modern frameworks and best practices.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 p-6 bg-slate-50 rounded-lg">
              <div className="flex items-center space-x-3 mb-4">
                <MapPin className="w-6 h-6 text-slate-600" />
                <h3 className="text-lg font-semibold text-slate-800">Based in Thrissur, Kerala</h3>
              </div>
              <p className="text-slate-600 mb-4">
                Located in the beautiful cultural capital of Kerala, I work with clients both locally and internationally. 
                The rich heritage and vibrant tech community here inspire my creative approach to development.
              </p>
              <div className="flex items-center space-x-3">
                <Coffee className="w-5 h-5 text-slate-600" />
                <span className="text-slate-600">
                  When I'm not coding, I'm exploring Kerala's backwaters or enjoying local coffee while planning my next project.
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-6 bg-gradient-to-br from-teal-50 to-blue-50 rounded-lg">
                  <div className="text-3xl font-bold text-teal-600 mb-2">{stat.number}</div>
                  <div className="text-slate-600 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-teal-600 to-blue-600 rounded-lg p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">My Approach</h3>
              <p className="text-teal-100 mb-6">
                I believe in creating solutions that are not just functional, but also beautiful and user-centered. Every project is an opportunity to push boundaries and deliver something exceptional.
              </p>
              <div className="flex flex-wrap gap-2">
                {['Problem Solving', 'Creative Thinking', 'Attention to Detail', 'Continuous Learning'].map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-white/20 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;