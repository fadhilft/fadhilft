import React, { useState } from 'react';
import { Monitor, Tablet, Smartphone } from 'lucide-react';

interface DevicePreviewProps {
  children: React.ReactNode;
  title?: string;
}

const DevicePreview: React.FC<DevicePreviewProps> = ({ children, title = "Portfolio Preview" }) => {
  const [activeDevice, setActiveDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  const devices = [
    { id: 'desktop' as const, icon: Monitor, label: 'Desktop', width: 'w-full', height: 'h-96' },
    { id: 'tablet' as const, icon: Tablet, label: 'Tablet', width: 'w-3/4', height: 'h-96' },
    { id: 'mobile' as const, icon: Smartphone, label: 'Mobile', width: 'w-80', height: 'h-96' },
  ];

  const getDeviceFrame = () => {
    switch (activeDevice) {
      case 'desktop':
        return 'rounded-lg border-8 border-slate-800 bg-slate-800';
      case 'tablet':
        return 'rounded-2xl border-8 border-slate-700 bg-slate-700';
      case 'mobile':
        return 'rounded-3xl border-8 border-slate-600 bg-slate-600 relative';
    }
  };

  const getScreenSize = () => {
    switch (activeDevice) {
      case 'desktop':
        return 'w-full h-full';
      case 'tablet':
        return 'w-full h-full';
      case 'mobile':
        return 'w-full h-full';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-slate-800 mb-4">{title}</h3>
        <div className="flex justify-center space-x-4">
          {devices.map((device) => (
            <button
              key={device.id}
              onClick={() => setActiveDevice(device.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                activeDevice === device.id
                  ? 'bg-gradient-to-r from-teal-600 to-blue-600 text-white shadow-lg'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <device.icon className="w-4 h-4" />
              <span className="font-medium">{device.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-center">
        <div className={`${devices.find(d => d.id === activeDevice)?.width} max-w-6xl transition-all duration-500`}>
          <div className={`${getDeviceFrame()} p-2 transition-all duration-500`}>
            {activeDevice === 'mobile' && (
              <>
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-16 h-1 bg-slate-400 rounded-full"></div>
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-12 h-12 bg-slate-500 rounded-full"></div>
              </>
            )}
            <div className={`${getScreenSize()} bg-white rounded overflow-hidden`}>
              <div className="w-full h-full overflow-y-auto">
                <div className={`transform transition-all duration-500 ${
                  activeDevice === 'mobile' ? 'scale-50 origin-top-left w-[200%] h-[200%]' :
                  activeDevice === 'tablet' ? 'scale-75 origin-top-left w-[133%] h-[133%]' :
                  'scale-100'
                }`}>
                  {children}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 text-center">
        <p className="text-slate-600 text-sm">
          Click the device icons above to see how the design adapts to different screen sizes
        </p>
      </div>
    </div>
  );
};

export default DevicePreview;