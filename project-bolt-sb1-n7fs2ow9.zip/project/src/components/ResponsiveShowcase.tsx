import React from 'react';
import DevicePreview from './DevicePreview';
import { Code, Palette, Layers, Smartphone, Tablet, Monitor } from 'lucide-react';

const ResponsiveShowcase: React.FC = () => {
  const features = [
    {
      icon: Monitor,
      title: 'Desktop First',
      description: 'Optimized for large screens with full-width layouts and detailed content presentation.',
      color: 'from-blue-500 to-indigo-500',
    },
    {
      icon: Tablet,
      title: 'Tablet Ready',
      description: 'Perfectly adapted for tablet viewing with touch-friendly interfaces and optimized spacing.',
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Smartphone,
      title: 'Mobile Optimized',
      description: 'Fully responsive mobile experience with intuitive navigation and fast loading times.',
      color: 'from-teal-500 to-cyan-500',
    },
  ];

  // Mini portfolio preview content
  const PreviewContent = () => (
    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900 min-h-screen">
      {/* Mini Header */}
      <header className="bg-white/95 backdrop-blur-sm shadow-lg p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-teal-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Code className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-bold text-slate-800">fadhilft</span>
          </div>
          <nav className="hidden md:flex space-x-6">
            <span className="text-slate-600 font-medium">About</span>
            <span className="text-slate-600 font-medium">Skills</span>
            <span className="text-slate-600 font-medium">Projects</span>
            <span className="text-slate-600 font-medium">Contact</span>
          </nav>
        </div>
      </header>

      {/* Mini Hero */}
      <section className="text-center py-16 px-4">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
          Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400">Fadhil</span>
        </h1>
        <p className="text-lg md:text-xl text-slate-300 mb-6">
          Full-Stack Developer, Web Designer & UI Developer
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-6 py-3 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-lg font-semibold">
            View My Work
          </button>
          <button className="px-6 py-3 border-2 border-white/30 text-white rounded-lg font-semibold">
            Get In Touch
          </button>
        </div>
      </section>

      {/* Mini About */}
      <section className="bg-white py-12 px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">About Me</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            I'm a passionate developer who loves creating exceptional digital experiences
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Code className="w-6 h-6 text-teal-600" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Full-Stack Development</h3>
            <p className="text-sm text-slate-600">Complete web applications from frontend to backend</p>
          </div>
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Palette className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Web Design</h3>
            <p className="text-sm text-slate-600">Visually stunning and user-friendly designs</p>
          </div>
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Layers className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">UI Development</h3>
            <p className="text-sm text-slate-600">Pixel-perfect, responsive interfaces</p>
          </div>
        </div>
      </section>

      {/* Mini Projects */}
      <section className="bg-slate-50 py-12 px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Featured Projects</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="h-32 bg-gradient-to-r from-green-500 to-emerald-500"></div>
            <div className="p-4">
              <h3 className="font-bold text-slate-800 mb-2">E-Commerce Platform</h3>
              <p className="text-sm text-slate-600">Full-featured e-commerce solution</p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="h-32 bg-gradient-to-r from-purple-500 to-pink-500"></div>
            <div className="p-4">
              <h3 className="font-bold text-slate-800 mb-2">Design System</h3>
              <p className="text-sm text-slate-600">Component library with Storybook</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-800 mb-6">
            Responsive Design Excellence
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Experience how my portfolio adapts seamlessly across all devices - from desktop to mobile
          </p>
        </div>

        {/* Device Preview */}
        <div className="mb-16">
          <DevicePreview title="Interactive Device Preview">
            <PreviewContent />
          </DevicePreview>
        </div>

        {/* Responsive Features */}
        <div className="grid lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
              <div className={`w-16 h-16 bg-gradient-to-r ${feature.color} rounded-lg flex items-center justify-center mb-6`}>
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-4">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Technical Details */}
        <div className="mt-16 bg-white rounded-xl shadow-lg p-8">
          <h3 className="text-2xl font-bold text-slate-800 mb-6 text-center">Technical Implementation</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">CSS</span>
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">CSS Grid & Flexbox</h4>
              <p className="text-sm text-slate-600">Modern layout techniques for perfect alignment</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">TW</span>
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Tailwind CSS</h4>
              <p className="text-sm text-slate-600">Utility-first framework for rapid development</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">RWD</span>
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Mobile-First</h4>
              <p className="text-sm text-slate-600">Progressive enhancement from mobile up</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">UX</span>
              </div>
              <h4 className="font-semibold text-slate-800 mb-2">Touch Optimized</h4>
              <p className="text-sm text-slate-600">Intuitive interactions across all devices</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResponsiveShowcase;