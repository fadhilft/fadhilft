import React from 'react';
import { Github, Linkedin, Mail, Heart, Code, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-teal-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Code className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">fadhilft</span>
            </div>
            <p className="text-slate-400 mb-4">
              Full-Stack Developer, Web Designer & UI Developer passionate about creating exceptional digital experiences.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://github.com/fadhilft"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-700 transition-colors duration-200 group"
              >
                <Github className="w-5 h-5 group-hover:text-slate-300" />
              </a>
              <a
                href="https://linkedin.com/in/fadhilft"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition-colors duration-200 group"
              >
                <Linkedin className="w-5 h-5 group-hover:text-blue-200" />
              </a>
              <a
                href="https://instagram.com/_fadhilft"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-pink-600 transition-colors duration-200 group"
              >
                <Instagram className="w-5 h-5 group-hover:text-pink-200" />
              </a>
              <a
                href="mailto:fadhilft637@gmail.com"
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-600 transition-colors duration-200 group"
              >
                <Mail className="w-5 h-5 group-hover:text-slate-300" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {[
                { name: 'About', href: '#about' },
                { name: 'Skills', href: '#skills' },
                { name: 'Projects', href: '#projects' },
                { name: 'Contact', href: '#contact' },
              ].map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-slate-400 hover:text-white transition-colors duration-200"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <a href="mailto:fadhilft637@gmail.com" className="hover:text-white transition-colors duration-200">
                  fadhilft637@gmail.com
                </a>
              </li>
              <li>
                <a href="tel:+918129031950" className="hover:text-white transition-colors duration-200">
                  +91 8129031950
                </a>
              </li>
              <li>
                <a href="https://instagram.com/_fadhilft" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors duration-200">
                  @_fadhilft
                </a>
              </li>
              <li>Thrissur, Akalad, Kerala</li>
              <li>Available for Remote Work</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-400 text-sm mb-4 md:mb-0">
            © {currentYear} fadhilft. All rights reserved.
          </p>
          <div className="flex items-center space-x-2 text-slate-400 text-sm">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-500" />
            <span>and lots of</span>
            <Code className="w-4 h-4 text-teal-500" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;