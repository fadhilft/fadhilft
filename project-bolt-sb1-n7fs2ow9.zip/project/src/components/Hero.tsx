import React, { useState, useEffect } from 'react';
import { ArrowDown, Github, Linkedin, Mail, MapPin, Instagram } from 'lucide-react';

const Hero: React.FC = () => {
  const [displayText, setDisplayText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);
  
  const roles = [
    'Full-Stack Developer',
    'Web Designer',
    'UI Developer'
  ];

  useEffect(() => {
    const currentRole = roles[currentRoleIndex];
    const typingSpeed = isDeleting ? 50 : 100;
    const pauseTime = isDeleting ? 1000 : 2000;

    const timer = setTimeout(() => {
      if (!isDeleting && currentIndex < currentRole.length) {
        setDisplayText(currentRole.substring(0, currentIndex + 1));
        setCurrentIndex(currentIndex + 1);
      } else if (isDeleting && currentIndex > 0) {
        setDisplayText(currentRole.substring(0, currentIndex - 1));
        setCurrentIndex(currentIndex - 1);
      } else if (!isDeleting && currentIndex === currentRole.length) {
        setTimeout(() => setIsDeleting(true), pauseTime);
      } else if (isDeleting && currentIndex === 0) {
        setIsDeleting(false);
        setCurrentRoleIndex((prevIndex) => (prevIndex + 1) % roles.length);
      }
    }, typingSpeed);

    return () => clearTimeout(timer);
  }, [currentIndex, isDeleting, currentRoleIndex, roles]);

  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900 flex items-center justify-center relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="animate-fade-in-up">
          {/* Profile Image */}
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <img
                src="/FT copy.jpg"
                alt="Fadhil FT"
                className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-white/20 shadow-2xl"
              />
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-teal-500/20 to-blue-500/20"></div>
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
            Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400">Fadhil</span>
          </h1>
          
          {/* Typewriter Animation */}
          <div className="text-xl md:text-2xl text-slate-300 mb-4 max-w-3xl mx-auto h-16 flex items-center justify-center">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400 font-semibold">
              {displayText}
              <span className="animate-pulse text-teal-400">|</span>
            </span>
          </div>
          
          {/* Location Badge */}
          <div className="flex items-center justify-center space-x-2 mb-8">
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full">
              <MapPin className="w-4 h-4 text-teal-400" />
              <span className="text-slate-300 text-sm">Thrissur, Akalad, Kerala</span>
            </div>
          </div>

          <p className="text-lg text-slate-400 mb-12 max-w-2xl mx-auto">
            I craft beautiful, functional web experiences that bring ideas to life. 
            From concept to deployment, I handle every aspect of modern web development.
          </p>

          {/* Social Links */}
          <div className="flex justify-center space-x-6 mb-12">
            <a
              href="https://github.com/fadhilft"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all duration-300 hover:scale-110 group"
            >
              <Github className="w-6 h-6 text-white group-hover:text-slate-200" />
            </a>
            <a
              href="https://linkedin.com/in/fadhilft"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-blue-500/20 transition-all duration-300 hover:scale-110 group"
            >
              <Linkedin className="w-6 h-6 text-white group-hover:text-blue-400" />
            </a>
            <a
              href="https://instagram.com/_fadhilft"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-pink-500/20 transition-all duration-300 hover:scale-110 group"
            >
              <Instagram className="w-6 h-6 text-white group-hover:text-pink-400" />
            </a>
            <a
              href="mailto:fadhilft637@gmail.com"
              className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-teal-500/20 transition-all duration-300 hover:scale-110 group"
            >
              <Mail className="w-6 h-6 text-white group-hover:text-teal-400" />
            </a>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={scrollToAbout}
              className="px-8 py-4 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-lg font-semibold hover:from-teal-700 hover:to-blue-700 transition-all duration-300 hover:scale-105 shadow-lg"
            >
              View My Work
            </button>
            <button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 border-2 border-white/30 text-white rounded-lg font-semibold hover:bg-white/10 transition-all duration-300 hover:scale-105"
            >
              Get In Touch
            </button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <button
          onClick={scrollToAbout}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce"
        >
          <ArrowDown className="w-6 h-6 text-white/70" />
        </button>
      </div>
    </section>
  );
};

export default Hero;