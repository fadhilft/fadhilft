import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import ResponsiveShowcase from './components/ResponsiveShowcase';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <About />
      <Skills />
      <ResponsiveShowcase />
      <Projects />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;